<template>
  <div>
      <h1>Contacts</h1>
  </div>
</template>
<script>
export default {
  name : "contacts"
}
</script>
