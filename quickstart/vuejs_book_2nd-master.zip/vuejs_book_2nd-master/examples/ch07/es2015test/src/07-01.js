let name = 'world';
console.log(`Hello ${name}`);