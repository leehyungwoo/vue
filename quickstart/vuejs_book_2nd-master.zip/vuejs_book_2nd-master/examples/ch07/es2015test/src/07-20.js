import calc2 from './utils/utility3';

console.log(calc2.add(4,5));
console.log(calc2.multiply(4,5));