export default {
    ADD_TODO : "addTodo",
    DONE_TOGGLE : "doneToggle",
    DELETE_TODO : "deleteTodo"
}