<template>
  <div>
      <h1>About</h1>
  </div>
</template>
<script>
export default {
  name : "about"
}
</script>
