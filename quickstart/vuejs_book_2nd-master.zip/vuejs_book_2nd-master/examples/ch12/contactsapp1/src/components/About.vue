<template>
  <div id="example">
    <div class="panel panel-default">
      <div class="panel-heading">About</div>
      <div class="panel-body">About 화면입니다</div>
    </div>
  </div>
</template>
<style>
#example { margin:10px auto; max-width: 820px; min-width: 820px;
    padding:0px; position:relative; font: 13px "verdana"; }
</style>