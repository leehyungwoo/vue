export default {
    CHANGE_REGION : "changeRegion"
}