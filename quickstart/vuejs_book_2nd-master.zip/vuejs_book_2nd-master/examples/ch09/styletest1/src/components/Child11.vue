<template>
  <div class="test">
    <h3>Child - Child</h3>
  </div>
</template>

<style scoped>
  .test { font-style:italic; }
</style>