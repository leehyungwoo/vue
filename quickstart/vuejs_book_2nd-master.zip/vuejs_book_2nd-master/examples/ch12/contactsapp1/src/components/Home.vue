<template>
  <div id="example">
    <div class="panel panel-default">
      <div class="panel-heading">Home</div>
      <div class="panel-body">Home 화면입니다</div>
    </div>
  </div>
</template>
<style>
#example { margin:10px auto; max-width: 820px; min-width: 820px;
    padding:0px; position:relative; font: 13px "verdana"; }
</style>